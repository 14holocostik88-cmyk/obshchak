#!/usr/bin/env bash
set -euo pipefail
umask 077
cd "$(dirname "$0")"

if [[ -e .env || -e Caddyfile ]]; then
  echo 'Конфигурация уже существует. Для сохранения данных установка остановлена.' >&2
  exit 1
fi

echo 'Установка панели «Общак»'
echo '1 — поддомен'
echo '2 — IP сервера'
read -r -p 'Выберите режим [1/2]: ' mode
case "$mode" in
  1) read -r -p 'Поддомен панели (например panel.example.com): ' host ;;
  2) read -r -p 'Публичный IPv4 сервера: ' host ;;
  *) echo 'Выберите 1 или 2' >&2; exit 1 ;;
esac

while true; do
  read -r -p 'Свободный TCP-порт для HTTP-панели (1–65535): ' panel_port
  if [[ ! "$panel_port" =~ ^[0-9]{1,5}$ ]] || (( 10#$panel_port < 1 || 10#$panel_port > 65535 )); then
    echo 'Введите номер порта от 1 до 65535.' >&2
    continue
  fi
  panel_port=$((10#$panel_port))
  if python3 - "$panel_port" <<'PY'
import errno
import socket
import sys

port = int(sys.argv[1])
for family, address in ((socket.AF_INET, ('0.0.0.0', port)), (socket.AF_INET6, ('::', port))):
    try:
        with socket.socket(family, socket.SOCK_STREAM) as sock:
            if family == socket.AF_INET6:
                sock.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_V6ONLY, 1)
            sock.bind(address)
    except OSError as exc:
        if family == socket.AF_INET6 and exc.errno in (errno.EAFNOSUPPORT, errno.EADDRNOTAVAIL):
            continue
        sys.exit(1)
PY
  then
    break
  fi
  echo "Порт $panel_port уже занят. Выберите другой." >&2
done

read -r -p 'Логин администратора: ' username
read -r -s -p 'Пароль администратора (не менее 12 символов): ' password
echo

if (( ${#password} < 12 )); then
  echo 'Пароль должен содержать не менее 12 символов' >&2
  exit 1
fi

python3 - "$mode" "$host" "$username" <<'PY'
import ipaddress
import re
import sys
mode, host, username = sys.argv[1:]
if mode == '1':
    if not re.fullmatch(r'(?=.{4,253}$)(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,63}', host):
        sys.exit('Неверное имя поддомена')
else:
    try:
        ipaddress.IPv4Address(host)
    except ValueError:
        sys.exit('Неверный IPv4-адрес')
if not re.fullmatch(r'[A-Za-z0-9_.-]{3,64}', username):
    sys.exit('Логин: 3–64 символа, латинские буквы, цифры, _, . и -')
PY

password_hash=$(printf '%s' "$password" | python3 -c 'import sys; from panel.security import hash_password; print(hash_password(sys.stdin.read()))')
unset password
cat > .env <<EOF
ADMIN_USERNAME=$username
ADMIN_PASSWORD_HASH=$password_hash
PANEL_PORT=$panel_port
EOF

cat > Caddyfile <<EOF
http://$host {
    encode zstd gzip
    reverse_proxy app:8000
}
EOF
if [[ "$panel_port" == 80 ]]; then url="http://$host"; else url="http://$host:$panel_port"; fi

mkdir -p data
chmod 700 data
echo "Конфигурация создана: $url"
echo 'Внимание: HTTP не шифрует логин, токены и ссылки подписок.'
if [[ "${1:-}" == '--prepare-only' ]]; then
  echo 'Режим проверки: контейнеры не запускались.'
  exit 0
fi
if ! command -v docker >/dev/null 2>&1 || ! docker compose version >/dev/null 2>&1; then
  echo 'Для запуска установите Docker Engine и Compose Plugin, затем выполните: docker compose up -d --build' >&2
  exit 1
fi
docker compose up -d --build --wait
echo "Откройте $url и войдите под созданным логином."
