import os
from pathlib import Path

from .app import create_app


app = create_app(Path(os.getenv("DATABASE_PATH", "./data/panel.db")),
                 os.getenv("ADMIN_USERNAME", "admin"), os.getenv("ADMIN_PASSWORD_HASH", ""))
