import base64
import calendar
import hashlib
import html
import json
import secrets
import sqlite3
import time
from contextlib import closing, contextmanager
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import quote, urlsplit

from fastapi import Depends, FastAPI, Header, HTTPException, Request
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, PlainTextResponse
from pydantic import BaseModel, Field

from .profiles import parse_profiles, vless_link
from .security import check_password


RENEWAL_LINK = (
    "ss://" + base64.urlsafe_b64encode(b"aes-128-gcm:renewal-only").decode().rstrip("=")
    + "@192.0.2.1:1#" + quote("продлите подписку", safe="")
)


class LoginInput(BaseModel):
    username: str
    password: str


class ImportInput(BaseModel):
    text: str = Field(min_length=2, max_length=2_000_000)


class HostPatch(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=120)
    enabled: bool | None = None


class SubscriberInput(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    title: str = Field(default="Общак", min_length=1, max_length=25)
    expires_at: datetime | None = None
    traffic_limit_gb: int | None = Field(default=None, gt=0, le=1_000_000)
    support_url: str | None = None


class SubscriberPatch(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=120)
    title: str | None = Field(default=None, min_length=1, max_length=25)
    enabled: bool | None = None
    expires_at: datetime | None = None
    traffic_limit_gb: int | None = Field(default=None, gt=0, le=1_000_000)
    support_url: str | None = None


class ApiKeyInput(BaseModel):
    name: str = Field(min_length=1, max_length=64)


class UsageInput(BaseModel):
    used_bytes: int = Field(ge=0, le=2**63 - 1)
    period_start: str = Field(min_length=1)


def monthly_period_start(created: datetime, now: datetime) -> datetime:
    if now < created:
        return created
    month_index = now.year * 12 + now.month - 1
    while True:
        year, month_zero = divmod(month_index, 12)
        month = month_zero + 1
        day = min(created.day, calendar.monthrange(year, month)[1])
        candidate = created.replace(year=year, month=month, day=day)
        if candidate <= now:
            return candidate
        month_index -= 1


def create_app(db_path: Path, admin_user: str, admin_password_hash: str) -> FastAPI:
    db_path = Path(db_path)
    db_path.parent.mkdir(parents=True, exist_ok=True)
    if not db_path.exists():
        db_path.touch(mode=0o600)
    with closing(sqlite3.connect(db_path)) as db:
        db.executescript("""
            CREATE TABLE IF NOT EXISTS hosts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                address TEXT NOT NULL,
                port INTEGER NOT NULL,
                network TEXT NOT NULL,
                security TEXT NOT NULL,
                link TEXT NOT NULL,
                source_json TEXT NOT NULL,
                enabled INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS subscribers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                token TEXT NOT NULL UNIQUE,
                expires_at TEXT,
                enabled INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS sessions (
                token_hash TEXT PRIMARY KEY,
                expires_at INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS api_keys (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                token_hash TEXT NOT NULL UNIQUE,
                created_at TEXT NOT NULL
            );
        """)
        columns = {row[1] for row in db.execute("PRAGMA table_info(subscribers)")}
        for name, definition in (
            ("title", "TEXT NOT NULL DEFAULT 'Общак'"),
            ("support_url", "TEXT"),
            ("traffic_limit_gb", "INTEGER"),
            ("used_bytes", "INTEGER NOT NULL DEFAULT 0"),
            ("usage_period_start", "TEXT"),
        ):
            if name not in columns:
                db.execute(f"ALTER TABLE subscribers ADD COLUMN {name} {definition}")
        db.commit()

    app = FastAPI(title="Общак API", version="1.1.0", docs_url="/api/docs", openapi_url="/api/openapi.json")

    @app.middleware("http")
    async def privacy_headers(request, call_next):
        response = await call_next(request)
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        if request.url.path.startswith("/api/v1/") or request.url.path.startswith("/sub/"):
            response.headers["Cache-Control"] = "no-store"
        return response

    @contextmanager
    def connect():
        with closing(sqlite3.connect(db_path)) as db:
            db.row_factory = sqlite3.Row
            with db:
                yield db

    def current_subscriber(db, row):
        subscriber = dict(row)
        period = monthly_period_start(datetime.fromisoformat(subscriber["created_at"]), datetime.now(timezone.utc)).isoformat()
        if subscriber["usage_period_start"] != period:
            db.execute("UPDATE subscribers SET used_bytes=0, usage_period_start=? WHERE id=?", (period, subscriber["id"]))
            subscriber["used_bytes"] = 0
            subscriber["usage_period_start"] = period
        return subscriber

    def require_admin(authorization: str | None = Header(default=None)):
        if not authorization or not authorization.startswith("Bearer "):
            raise HTTPException(401, "Требуется токен администратора")
        token_hash = hashlib.sha256(authorization[7:].encode()).hexdigest()
        with connect() as db:
            found = db.execute("SELECT 1 FROM sessions WHERE token_hash=? AND expires_at>?", (token_hash, int(time.time()))).fetchone()
        if not found:
            raise HTTPException(401, "Сессия истекла или недействительна")
        return token_hash

    def require_subscriber_access(authorization: str | None = Header(default=None)):
        if not authorization or not authorization.startswith("Bearer "):
            raise HTTPException(401, "Требуется токен администратора или API-ключ")
        token_hash = hashlib.sha256(authorization[7:].encode()).hexdigest()
        with connect() as db:
            session = db.execute("SELECT 1 FROM sessions WHERE token_hash=? AND expires_at>?", (token_hash, int(time.time()))).fetchone()
            api_key = db.execute("SELECT 1 FROM api_keys WHERE token_hash=?", (token_hash,)).fetchone()
        if not session and not api_key:
            raise HTTPException(401, "Недействительный токен или API-ключ")
        return token_hash

    def get_host(host_id: int):
        with connect() as db:
            row = db.execute("SELECT * FROM hosts WHERE id=?", (host_id,)).fetchone()
        if not row:
            raise HTTPException(404, "Хост не найден")
        return dict(row)

    def get_subscriber(subscriber_id: int):
        with connect() as db:
            row = db.execute("SELECT * FROM subscribers WHERE id=?", (subscriber_id,)).fetchone()
            if row:
                return current_subscriber(db, row)
        if not row:
            raise HTTPException(404, "Подписчик не найден")

    def valid_expiry(value: datetime | None):
        if value is None:
            return None
        if value.tzinfo is None:
            raise HTTPException(422, "Укажите часовой пояс в expires_at, например Z")
        return value.astimezone(timezone.utc).isoformat()

    def valid_support_url(value: str | None):
        if value is None or not value.strip():
            return None
        value = value.strip()
        try:
            parsed = urlsplit(value)
            hostname = parsed.hostname
        except ValueError:
            raise HTTPException(422, "Неверная ссылка поддержки") from None
        if parsed.scheme not in ("http", "https") or not hostname or any(ord(ch) < 33 for ch in value):
            raise HTTPException(422, "Укажите ссылку поддержки с http:// или https://")
        return value

    def subscriber_response(subscriber: dict, request: Request):
        return {**subscriber, "subscription_url": str(request.url_for("subscription", token=subscriber["token"]))}

    @app.get("/", include_in_schema=False)
    def index():
        return FileResponse(Path(__file__).parent / "static" / "index.html")

    @app.get("/assets/{filename}", include_in_schema=False)
    def asset(filename: str):
        if filename not in ("app.js", "style.css"):
            raise HTTPException(404)
        return FileResponse(Path(__file__).parent / "static" / filename)

    @app.get("/health", include_in_schema=False)
    def health():
        return {"ok": True}

    @app.post("/api/v1/auth/login")
    def login(body: LoginInput):
        if not (secrets.compare_digest(body.username, admin_user) and check_password(body.password, admin_password_hash)):
            raise HTTPException(401, "Неверный логин или пароль")
        token = secrets.token_urlsafe(32)
        expires_at = int(time.time()) + 12 * 3600
        with connect() as db:
            db.execute("DELETE FROM sessions WHERE expires_at<=?", (int(time.time()),))
            db.execute("INSERT INTO sessions(token_hash, expires_at) VALUES (?,?)", (hashlib.sha256(token.encode()).hexdigest(), expires_at))
        return {"token": token, "expires_at": expires_at}

    @app.post("/api/v1/auth/logout", status_code=204)
    def logout(token_hash: str = Depends(require_admin)):
        with connect() as db:
            db.execute("DELETE FROM sessions WHERE token_hash=?", (token_hash,))

    @app.get("/api/v1/api-keys")
    def list_api_keys(_: str = Depends(require_admin)):
        with connect() as db:
            rows = db.execute("SELECT id,name,created_at FROM api_keys ORDER BY id DESC").fetchall()
        return {"api_keys": [dict(row) for row in rows]}

    @app.post("/api/v1/api-keys", status_code=201)
    def create_api_key(body: ApiKeyInput, _: str = Depends(require_admin)):
        name = body.name.strip()
        if not name:
            raise HTTPException(422, "Название ключа не может быть пустым")
        key = "ok_" + secrets.token_urlsafe(32)
        with connect() as db:
            cursor = db.execute("INSERT INTO api_keys(name,token_hash,created_at) VALUES (?,?,?)",
                                (name, hashlib.sha256(key.encode()).hexdigest(), datetime.now(timezone.utc).isoformat()))
            key_id = cursor.lastrowid
        return {"id": key_id, "name": name, "key": key}

    @app.delete("/api/v1/api-keys/{key_id}", status_code=204)
    def delete_api_key(key_id: int, _: str = Depends(require_admin)):
        with connect() as db:
            cursor = db.execute("DELETE FROM api_keys WHERE id=?", (key_id,))
            if not cursor.rowcount:
                raise HTTPException(404, "API-ключ не найден")

    @app.get("/api/v1/hosts")
    def list_hosts(_: str = Depends(require_admin)):
        with connect() as db:
            rows = db.execute("SELECT id,name,address,port,network,security,enabled,created_at FROM hosts ORDER BY id DESC").fetchall()
        return {"hosts": [dict(r) for r in rows]}

    @app.post("/api/v1/hosts/import", status_code=201)
    def import_hosts(body: ImportInput, _: str = Depends(require_admin)):
        try:
            profiles = parse_profiles(body.text)
            links = [vless_link(p) for p in profiles]
        except ValueError as exc:
            raise HTTPException(422, str(exc)) from exc
        now = datetime.now(timezone.utc).isoformat()
        ids = []
        with connect() as db:
            for profile, link in zip(profiles, links):
                cursor = db.execute("INSERT INTO hosts(name,address,port,network,security,link,source_json,created_at) VALUES (?,?,?,?,?,?,?,?)",
                                    (profile["name"], profile["address"], profile["port"], profile["network"], profile["security"], link,
                                     json.dumps(profile["source"], ensure_ascii=False), now))
                ids.append(cursor.lastrowid)
        return {"hosts": [get_host_public(get_host(host_id)) for host_id in ids]}

    @app.get("/api/v1/hosts/{host_id}")
    def show_host(host_id: int, _: str = Depends(require_admin)):
        return get_host_public(get_host(host_id))

    @app.get("/api/v1/hosts/{host_id}/source")
    def host_source(host_id: int, _: str = Depends(require_admin)):
        return JSONResponse(json.loads(get_host(host_id)["source_json"]))

    @app.patch("/api/v1/hosts/{host_id}")
    def update_host(host_id: int, body: HostPatch, _: str = Depends(require_admin)):
        host = get_host(host_id)
        name = body.name.strip() if body.name is not None else host["name"]
        if not name:
            raise HTTPException(422, "Имя не может быть пустым")
        enabled = int(body.enabled) if body.enabled is not None else host["enabled"]
        link = host["link"]
        if name != host["name"]:
            link = link.split("#", 1)[0] + "#" + quote(name, safe="")
        with connect() as db:
            db.execute("UPDATE hosts SET name=?, enabled=?, link=? WHERE id=?", (name, enabled, link, host_id))
        return get_host_public(get_host(host_id))

    @app.delete("/api/v1/hosts/{host_id}", status_code=204)
    def delete_host(host_id: int, _: str = Depends(require_admin)):
        get_host(host_id)
        with connect() as db:
            db.execute("DELETE FROM hosts WHERE id=?", (host_id,))

    @app.get("/api/v1/users")
    @app.get("/api/v1/subscribers")
    def list_subscribers(request: Request, _: str = Depends(require_subscriber_access)):
        with connect() as db:
            rows = db.execute("SELECT * FROM subscribers ORDER BY id DESC").fetchall()
            subscribers = [current_subscriber(db, row) for row in rows]
        return {"subscribers": [subscriber_response(subscriber, request) for subscriber in subscribers]}

    @app.post("/api/v1/users", status_code=201)
    @app.post("/api/v1/subscribers", status_code=201)
    def create_subscriber(body: SubscriberInput, request: Request, _: str = Depends(require_subscriber_access)):
        token = secrets.token_urlsafe(32)
        expiry = valid_expiry(body.expires_at)
        name = body.name.strip()
        if not name:
            raise HTTPException(422, "Имя покупателя не может быть пустым")
        title = body.title.strip()
        if not title:
            raise HTTPException(422, "Название подписки не может быть пустым")
        now = datetime.now(timezone.utc).isoformat()
        with connect() as db:
            cursor = db.execute("INSERT INTO subscribers(name,title,token,expires_at,traffic_limit_gb,support_url,created_at,usage_period_start) VALUES (?,?,?,?,?,?,?,?)",
                                (name, title, token, expiry, body.traffic_limit_gb,
                                 valid_support_url(body.support_url), now, now))
            subscriber_id = cursor.lastrowid
        return subscriber_response(get_subscriber(subscriber_id), request)

    @app.get("/api/v1/users/{subscriber_id}")
    @app.get("/api/v1/subscribers/{subscriber_id}")
    def show_subscriber(subscriber_id: int, request: Request, _: str = Depends(require_subscriber_access)):
        return subscriber_response(get_subscriber(subscriber_id), request)

    @app.patch("/api/v1/users/{subscriber_id}")
    @app.patch("/api/v1/subscribers/{subscriber_id}")
    def update_subscriber(subscriber_id: int, body: SubscriberPatch, request: Request, _: str = Depends(require_subscriber_access)):
        current = get_subscriber(subscriber_id)
        name = body.name.strip() if body.name is not None else current["name"]
        if not name:
            raise HTTPException(422, "Имя не может быть пустым")
        title = body.title.strip() if body.title is not None else current["title"]
        if not title:
            raise HTTPException(422, "Название подписки не может быть пустым")
        enabled = int(body.enabled) if body.enabled is not None else current["enabled"]
        expiry = valid_expiry(body.expires_at) if "expires_at" in body.model_fields_set else current["expires_at"]
        limit = body.traffic_limit_gb if "traffic_limit_gb" in body.model_fields_set else current["traffic_limit_gb"]
        support_url = valid_support_url(body.support_url) if "support_url" in body.model_fields_set else current["support_url"]
        with connect() as db:
            db.execute("UPDATE subscribers SET name=?, title=?, enabled=?, expires_at=?, traffic_limit_gb=?, support_url=? WHERE id=?",
                       (name, title, enabled, expiry, limit, support_url, subscriber_id))
        return subscriber_response(get_subscriber(subscriber_id), request)

    @app.post("/api/v1/users/{subscriber_id}/rotate")
    @app.post("/api/v1/subscribers/{subscriber_id}/rotate")
    def rotate_subscriber(subscriber_id: int, request: Request, _: str = Depends(require_subscriber_access)):
        get_subscriber(subscriber_id)
        token = secrets.token_urlsafe(32)
        with connect() as db:
            db.execute("UPDATE subscribers SET token=? WHERE id=?", (token, subscriber_id))
        return subscriber_response(get_subscriber(subscriber_id), request)

    @app.delete("/api/v1/users/{subscriber_id}", status_code=204)
    @app.delete("/api/v1/subscribers/{subscriber_id}", status_code=204)
    def delete_subscriber(subscriber_id: int, _: str = Depends(require_subscriber_access)):
        get_subscriber(subscriber_id)
        with connect() as db:
            db.execute("DELETE FROM subscribers WHERE id=?", (subscriber_id,))

    @app.put("/api/v1/users/{subscriber_id}/usage")
    @app.put("/api/v1/subscribers/{subscriber_id}/usage")
    def report_usage(subscriber_id: int, body: UsageInput, request: Request, _: str = Depends(require_subscriber_access)):
        with connect() as db:
            row = db.execute("SELECT * FROM subscribers WHERE id=?", (subscriber_id,)).fetchone()
            if not row:
                raise HTTPException(404, "Подписчик не найден")
            current = current_subscriber(db, row)
            if body.period_start != current["usage_period_start"]:
                raise HTTPException(409, "Период учёта изменился; получите актуальный usage_period_start")
            db.execute("UPDATE subscribers SET used_bytes=? WHERE id=?", (body.used_bytes, subscriber_id))
        return subscriber_response(get_subscriber(subscriber_id), request)

    def subscription_links(token: str):
        with connect() as db:
            subscriber = db.execute("SELECT * FROM subscribers WHERE token=?", (token,)).fetchone()
            if not subscriber or not subscriber["enabled"]:
                raise HTTPException(404, "Подписка недоступна")
            subscriber = current_subscriber(db, subscriber)
            if subscriber["expires_at"] and datetime.fromisoformat(subscriber["expires_at"]) <= datetime.now(timezone.utc):
                return [RENEWAL_LINK], subscriber
            if subscriber["traffic_limit_gb"] and subscriber["used_bytes"] >= subscriber["traffic_limit_gb"] * 1024**3:
                return [RENEWAL_LINK], subscriber
            links = [r[0] for r in db.execute("SELECT link FROM hosts WHERE enabled=1 ORDER BY id")]
        return links, subscriber

    def subscription_raw_response(token: str, request: Request):
        links, subscriber = subscription_links(token)
        payload = base64.b64encode(("\n".join(links) + ("\n" if links else "")).encode()).decode()
        expiry = int(datetime.fromisoformat(subscriber["expires_at"]).timestamp()) if subscriber["expires_at"] else 0
        total = (subscriber["traffic_limit_gb"] or 0) * 1024**3
        headers = {
            "Cache-Control": "no-store",
            "subscription-userinfo": f"upload=0; download={subscriber['used_bytes']}; total={total}; expire={expiry}",
            "profile-title": base64.b64encode(subscriber["title"].encode()).decode(),
            "profile-web-page-url": str(request.url_for("subscription", token=token)),
            "hide-settings": "1",
            "Content-Disposition": 'attachment; filename="subscription.txt"',
        }
        if subscriber["support_url"]:
            headers["support-url"] = subscriber["support_url"]
        if links == [RENEWAL_LINK]:
            headers["sub-expire"] = "1"
            if subscriber["support_url"]:
                headers["sub-expire-button-link"] = subscriber["support_url"]
        return PlainTextResponse(payload, headers=headers)

    @app.get("/sub/{token}")
    def subscription(token: str, request: Request):
        links, subscriber = subscription_links(token)
        if "text/html" not in request.headers.get("accept", "") or "happ" in request.headers.get("user-agent", "").lower():
            return subscription_raw_response(token, request)
        raw_url = str(request.url_for("subscription_raw", token=token))
        title = html.escape(subscriber["title"])
        support = (f'<a class="support" href="{html.escape(subscriber["support_url"], quote=True)}" rel="noopener">Поддержка</a>'
                   if subscriber["support_url"] else "")
        if subscriber["expires_at"] and datetime.fromisoformat(subscriber["expires_at"]) <= datetime.now(timezone.utc):
            status = "Срок подписки истёк"
        elif links == [RENEWAL_LINK]:
            status = "Лимит трафика исчерпан"
        else:
            status = "Подписка готова к добавлению"
        page = f'''<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#26221f"><title>{title} — Общак</title><link rel="stylesheet" href="/assets/style.css"></head><body class="subscription-page"><main class="subscription-card"><span class="sub-brand">Общак</span><h1>{title}</h1><p>{status}</p><a class="primary happ-button" href="happ://add/{html.escape(raw_url, quote=True)}">Добавить в Happ</a><label>Ссылка подписки<input readonly onclick="this.select()" value="{html.escape(raw_url, quote=True)}"></label>{support}</main></body></html>'''
        return HTMLResponse(page, headers={"Cache-Control": "no-store"})

    @app.get("/sub/{token}/raw")
    def subscription_raw(token: str, request: Request):
        return subscription_raw_response(token, request)

    @app.get("/sub/{token}/links")
    def subscription_plain_links(token: str):
        links, _ = subscription_links(token)
        return PlainTextResponse("\n".join(links) + ("\n" if links else ""),
                                 headers={"Cache-Control": "no-store", "hide-settings": "1"})

    return app


def get_host_public(host: dict) -> dict:
    return {key: host[key] for key in ("id", "name", "address", "port", "network", "security", "enabled", "created_at")}
