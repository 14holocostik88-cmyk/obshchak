import json
from copy import deepcopy
from urllib.parse import quote, urlencode


def parse_profiles(text: str) -> list[dict]:
    """Extract VLESS hosts from one Xray client configuration."""
    try:
        source = json.loads(text)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Неверный JSON: {exc.msg}") from exc
    if not isinstance(source, dict) or not isinstance(source.get("outbounds"), list):
        raise ValueError("Нужен JSON-конфиг Xray с массивом outbounds")

    profiles = []
    for outbound in source["outbounds"]:
        if not isinstance(outbound, dict):
            continue
        protocol = outbound.get("protocol")
        if protocol in ("freedom", "blackhole", "dns"):
            continue
        if protocol != "vless":
            raise ValueError(f"Пока поддерживается только VLESS; найден {protocol or 'пустой протокол'}")
        stream = outbound.get("streamSettings") or {}
        network = stream.get("network", "tcp")
        security = stream.get("security", "none")
        if network not in ("xhttp", "grpc", "tcp", "ws") or security not in ("reality", "tls"):
            raise ValueError(f"Неподдерживаемый VLESS: transport={network}, security={security}")
        settings = outbound.get("settings") or {}
        destinations = settings.get("vnext") or []
        if not destinations and settings.get("address"):
            destinations = [{"address": settings.get("address"), "port": settings.get("port"), "users": [settings]}]
        if len(destinations) != 1 or len(destinations[0].get("users") or []) != 1:
            raise ValueError("Каждый VLESS outbound должен содержать ровно один адрес и одного пользователя")
        destination = destinations[0]
        user = destination["users"][0]
        address, port, uid = destination.get("address"), destination.get("port"), user.get("id")
        if not isinstance(address, str) or not address or not isinstance(port, int) or not 1 <= port <= 65535 or not isinstance(uid, str) or not uid:
            raise ValueError("У VLESS outbound неверный address, port или id")
        tag = outbound.get("tag") or address
        remark = source.get("remarks")
        name = f"{remark} · {tag}" if isinstance(remark, str) and remark.strip() else tag
        profiles.append({"name": name, "address": address, "port": port, "network": network, "security": security,
                         "outbound": deepcopy(outbound), "source": deepcopy(source)})
    if not profiles:
        raise ValueError("В конфиге нет VLESS-подключений")
    return profiles


def vless_link(profile: dict) -> str:
    outbound = profile["outbound"]
    stream = outbound.get("streamSettings") or {}
    destination = (outbound.get("settings") or {}).get("vnext")
    if destination:
        user = destination[0]["users"][0]
    else:
        user = outbound["settings"]
    network = profile["network"]
    security = profile["security"]
    fields = [("encryption", user.get("encryption") or "none"), ("security", security), ("type", network)]
    if user.get("flow"):
        fields.append(("flow", user["flow"]))
    if security == "reality":
        reality = stream.get("realitySettings") or {}
        for key, value in (("sni", reality.get("serverName")), ("fp", reality.get("fingerprint")),
                           ("pbk", reality.get("publicKey")), ("sid", reality.get("shortId")),
                           ("spx", reality.get("spiderX"))):
            if value:
                fields.append((key, value))
    else:
        tls = stream.get("tlsSettings") or {}
        for key, value in (("sni", tls.get("serverName")), ("alpn", ",".join(tls.get("alpn", [])))):
            if value:
                fields.append((key, value))
    transport = stream.get({"xhttp": "xhttpSettings", "grpc": "grpcSettings", "ws": "wsSettings", "tcp": "tcpSettings"}[network]) or {}
    if network in ("xhttp", "ws"):
        host = transport.get("host") or (transport.get("headers") or {}).get("Host")
        if host:
            fields.append(("host", host))
        if transport.get("path"):
            fields.append(("path", transport["path"]))
        if network == "xhttp" and transport.get("mode"):
            fields.append(("mode", transport["mode"]))
    elif network == "grpc":
        for key in ("serviceName", "authority"):
            if transport.get(key):
                fields.append((key, transport[key]))
    address = profile["address"]
    if ":" in address and not address.startswith("["):
        address = f"[{address}]"
    query = urlencode(fields, quote_via=quote)
    return f"vless://{quote(user['id'], safe='')}@{address}:{profile['port']}?{query}#{quote(profile['name'], safe='')}"
