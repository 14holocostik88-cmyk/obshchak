const $ = (id) => document.getElementById(id);
let token = sessionStorage.getItem('relay-token');
let hosts = [];
let subscribers = [];
let editing = null;

async function api(path, method = 'GET', body) {
  const response = await fetch(path, {
    method,
    headers: {
      'Authorization': `Bearer ${token}`,
      ...(body === undefined ? {} : {'Content-Type': 'application/json'}),
    },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  if (response.status === 401 && path !== '/api/v1/auth/login') showLogin();
  if (!response.ok) {
    const data = await response.json().catch(() => ({}));
    const detail = data.detail;
    throw new Error(typeof detail === 'string' ? detail : `Ошибка ${response.status}`);
  }
  return response.status === 204 ? null : response.json();
}

function showLogin() {
  token = null;
  sessionStorage.removeItem('relay-token');
  $('workspace').hidden = true;
  $('login-screen').hidden = false;
}

function showWorkspace() {
  $('login-screen').hidden = true;
  $('workspace').hidden = false;
}

function toast(message) {
  const el = $('toast');
  el.textContent = message;
  el.classList.add('visible');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => el.classList.remove('visible'), 3500);
}

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function button(label, className, handler) {
  const node = el('button', className, label);
  node.type = 'button';
  node.addEventListener('click', handler);
  return node;
}

function setView(name) {
  for (const view of ['hosts', 'subscribers', 'api']) $('view-' + view).hidden = view !== name;
  document.querySelectorAll('.nav-item').forEach((item) => item.classList.toggle('active', item.dataset.view === name));
  $('section-path').textContent = {hosts: 'Хосты', subscribers: 'Подписчики', api: 'API'}[name];
}

function statusPill(active, label) {
  return el('span', `pill ${active ? 'active' : 'inactive'}`, label || (active ? 'Активен' : 'Отключён'));
}

function actionGroup() { return el('div', 'row-actions'); }

async function copyText(value) {
  if (navigator.clipboard) {
    try { await navigator.clipboard.writeText(value); return true; } catch {}
  }
  const field = document.createElement('textarea');
  field.value = value;
  field.style.position = 'fixed';
  field.style.opacity = '0';
  document.body.append(field);
  field.select();
  const copied = document.execCommand('copy');
  field.remove();
  return copied;
}

function renderHosts() {
  $('nav-host-count').textContent = String(hosts.length);
  $('host-empty').hidden = hosts.length > 0;
  $('host-list').replaceChildren();
  for (const host of hosts) {
    const row = el('div', 'row');
    const identity = el('div', 'identity');
    identity.append(el('strong', '', host.name), el('small', '', `${host.address}:${host.port}`));
    row.append(identity, el('span', 'protocol', `VLESS · ${host.network.toUpperCase()} · ${host.security.toUpperCase()}`), statusPill(!!host.enabled));
    const actions = actionGroup();
    actions.append(
      button('Изменить', 'small-button', () => openEdit('host', host)),
      button(host.enabled ? 'Отключить' : 'Включить', 'small-button', async () => {
        try { await api(`/api/v1/hosts/${host.id}`, 'PATCH', {enabled: !host.enabled}); await refresh(); toast('Статус хоста изменён'); }
        catch (error) { toast(error.message); }
      }),
      button('Удалить', 'small-button danger', async () => {
        if (!confirm(`Удалить хост «${host.name}»?`)) return;
        try { await api(`/api/v1/hosts/${host.id}`, 'DELETE'); await refresh(); toast('Хост удалён'); }
        catch (error) { toast(error.message); }
      }),
    );
    row.append(actions);
    $('host-list').append(row);
  }
}

function renderSubscribers() {
  $('nav-sub-count').textContent = String(subscribers.length);
  $('subscriber-empty').hidden = subscribers.length > 0;
  $('subscriber-list').replaceChildren();
  for (const subscriber of subscribers) {
    const wrap = el('div', 'subscriber-item');
    const row = el('div', 'row');
    const identity = el('div', 'identity');
    identity.append(el('strong', '', subscriber.name), el('small', '', `${subscriber.title} · ID ${subscriber.id}`));
    const expiry = subscriber.expires_at ? new Date(subscriber.expires_at).toLocaleDateString('ru-RU') : 'Без срока';
    const expired = subscriber.expires_at && new Date(subscriber.expires_at) <= new Date();
    const limited = subscriber.traffic_limit_gb && subscriber.used_bytes >= subscriber.traffic_limit_gb * 1024 ** 3;
    const active = subscriber.enabled && !expired && !limited;
    const traffic = subscriber.traffic_limit_gb
      ? `${(subscriber.used_bytes / 1024 ** 3).toFixed(1)} / ${subscriber.traffic_limit_gb} ГБ`
      : 'Без лимита';
    const status = !subscriber.enabled ? 'Отключён' : expired ? 'Истёк' : limited ? 'Лимит' : 'Активен';
    row.append(identity, el('span', 'protocol', `${expiry} · ${traffic}`), statusPill(active, status));
    const actions = actionGroup();
    actions.append(
      button('Изменить', 'small-button', () => openEdit('subscriber', subscriber)),
      button(subscriber.enabled ? 'Отключить' : 'Включить', 'small-button', async () => {
        try { await api(`/api/v1/subscribers/${subscriber.id}`, 'PATCH', {enabled: !subscriber.enabled}); await refresh(); toast('Статус подписчика изменён'); }
        catch (error) { toast(error.message); }
      }),
      button('Новая ссылка', 'small-button', async () => {
        if (!confirm(`Обновить ссылку для «${subscriber.name}»? Старая перестанет работать.`)) return;
        try { await api(`/api/v1/subscribers/${subscriber.id}/rotate`, 'POST'); await refresh(); toast('Ссылка обновлена'); }
        catch (error) { toast(error.message); }
      }),
      button('Удалить', 'small-button danger', async () => {
        if (!confirm(`Удалить подписчика «${subscriber.name}»?`)) return;
        try { await api(`/api/v1/subscribers/${subscriber.id}`, 'DELETE'); await refresh(); toast('Подписчик удалён'); }
        catch (error) { toast(error.message); }
      }),
    );
    row.append(actions);
    const url = subscriber.subscription_url || `${location.origin}/sub/${subscriber.token}`;
    const linkline = el('div', 'subscription-link');
    const urlText = el('span', '', url);
    urlText.title = url;
    const pageLink = el('a', 'copy-button', 'Страница');
    pageLink.href = url;
    pageLink.target = '_blank';
    pageLink.rel = 'noopener';
    linkline.append(urlText, pageLink, button('Копировать', 'copy-button', async () => {
      if (await copyText(url)) toast('Ссылка скопирована');
      else toast('Не удалось скопировать ссылку');
    }));
    wrap.append(row, linkline);
    $('subscriber-list').append(wrap);
  }
}

async function refresh() {
  const [hostResult, subscriberResult, keyResult] = await Promise.all([
    api('/api/v1/hosts'), api('/api/v1/subscribers'), api('/api/v1/api-keys'),
  ]);
  hosts = hostResult.hosts;
  subscribers = subscriberResult.subscribers;
  renderHosts();
  renderSubscribers();
  renderApiKeys(keyResult.api_keys);
  showWorkspace();
}

function renderApiKeys(keys) {
  $('api-key-list').replaceChildren();
  for (const key of keys) {
    const row = el('div', 'api-key-row');
    row.append(el('span', '', key.name), button('Отозвать', 'small-button danger', async () => {
      if (!confirm(`Отозвать ключ «${key.name}»? Бот перестанет работать с API.`)) return;
      try { await api(`/api/v1/api-keys/${key.id}`, 'DELETE'); await refresh(); toast('Ключ отозван'); }
      catch (error) { toast(error.message); }
    }));
    $('api-key-list').append(row);
  }
}

function openEdit(kind, item) {
  editing = {kind, id: item.id};
  $('edit-title').textContent = kind === 'host' ? 'Изменить хост' : 'Изменить подписчика';
  $('edit-form').elements.name.value = item.name;
  $('edit-subscription-fields').hidden = kind === 'host';
  $('edit-form').elements.title.value = kind === 'subscriber' ? item.title : '';
  $('edit-form').elements.expires_at.value = kind === 'subscriber' && item.expires_at
    ? new Date(item.expires_at).toLocaleString('sv-SE').slice(0, 16).replace(' ', 'T') : '';
  $('edit-form').elements.traffic_limit_gb.value = kind === 'subscriber' ? item.traffic_limit_gb || '' : '';
  $('edit-form').elements.support_url.value = kind === 'subscriber' ? item.support_url || '' : '';
  $('edit-error').textContent = '';
  $('edit-dialog').showModal();
}

function isoFromLocal(value) { return value ? new Date(value).toISOString() : null; }

document.querySelectorAll('.nav-item').forEach((item) => item.addEventListener('click', () => setView(item.dataset.view)));
document.querySelectorAll('.close-dialog').forEach((item) => item.addEventListener('click', () => item.closest('dialog').close()));
for (const [id, dialog] of [['open-import', 'import-dialog'], ['empty-import', 'import-dialog'], ['open-subscriber', 'subscriber-dialog'], ['empty-subscriber', 'subscriber-dialog']]) {
  $(id).addEventListener('click', () => { $(dialog).showModal(); $(dialog).querySelector('.error').textContent = ''; });
}

$('login-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  $('login-error').textContent = '';
  const form = new FormData(event.target);
  try {
    const response = await api('/api/v1/auth/login', 'POST', {username: form.get('username'), password: form.get('password')});
    token = response.token;
    sessionStorage.setItem('relay-token', token);
    event.target.reset();
    await refresh();
  } catch (error) { $('login-error').textContent = error.message; }
});

$('logout').addEventListener('click', async () => {
  try { await api('/api/v1/auth/logout', 'POST'); } catch {}
  showLogin();
});

$('import-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  $('import-error').textContent = '';
  try {
    const result = await api('/api/v1/hosts/import', 'POST', {text: event.target.elements.text.value});
    event.target.reset();
    $('import-dialog').close();
    await refresh();
    toast(`Добавлено хостов: ${result.hosts.length}`);
  } catch (error) { $('import-error').textContent = error.message; }
});

$('subscriber-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  $('subscriber-error').textContent = '';
  try {
    await api('/api/v1/subscribers', 'POST', {
      name: event.target.elements.name.value.trim(),
      title: event.target.elements.title.value.trim(),
      expires_at: isoFromLocal(event.target.elements.expires_at.value),
      traffic_limit_gb: event.target.elements.traffic_limit_gb.value ? Number(event.target.elements.traffic_limit_gb.value) : null,
      support_url: event.target.elements.support_url.value.trim() || null,
    });
    event.target.reset();
    $('subscriber-dialog').close();
    await refresh();
    setView('subscribers');
    toast('Ссылка подписчика создана');
  } catch (error) { $('subscriber-error').textContent = error.message; }
});

$('edit-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  $('edit-error').textContent = '';
  const body = {name: event.target.elements.name.value.trim()};
  if (editing.kind === 'subscriber') {
    body.title = event.target.elements.title.value.trim();
    body.expires_at = isoFromLocal(event.target.elements.expires_at.value);
    body.traffic_limit_gb = event.target.elements.traffic_limit_gb.value ? Number(event.target.elements.traffic_limit_gb.value) : null;
    body.support_url = event.target.elements.support_url.value.trim() || null;
  }
  const path = editing.kind === 'host' ? 'hosts' : 'subscribers';
  try {
    await api(`/api/v1/${path}/${editing.id}`, 'PATCH', body);
    $('edit-dialog').close();
    await refresh();
    toast('Изменения сохранены');
  } catch (error) { $('edit-error').textContent = error.message; }
});

$('api-key-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  $('api-key-error').textContent = '';
  try {
    const result = await api('/api/v1/api-keys', 'POST', {name: event.target.elements.name.value.trim()});
    $('api-key-value').value = result.key;
    $('new-api-key').hidden = false;
    await refresh();
    $('api-key-value').select();
    toast('Сохраните ключ: позже он не показывается');
  } catch (error) { $('api-key-error').textContent = error.message; }
});

if (token) refresh().catch(() => showLogin());
