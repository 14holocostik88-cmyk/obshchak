import base64
import json
import sqlite3
import tempfile
import unittest
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import unquote

from fastapi.testclient import TestClient

from panel import app as panel_app
from panel.app import create_app
from panel.profiles import parse_profiles, vless_link
from panel.security import hash_password


SAMPLE = {
    "dns": {"servers": ["1.1.1.1"]},
    "inbounds": [{"listen": "127.0.0.1", "port": 10808, "protocol": "socks"}],
    "outbounds": [
        {
            "tag": "pl",
            "protocol": "vless",
            "settings": {"vnext": [{"address": "example.org", "port": 443, "users": [{"id": "11111111-2222-4333-8444-555555555555", "encryption": "none"}]}]},
            "streamSettings": {"network": "xhttp", "security": "reality", "realitySettings": {"serverName": "example.org", "publicKey": "test_public_key", "fingerprint": "firefox"}, "xhttpSettings": {"path": "/xhttp", "mode": "auto"}},
        },
        {
            "tag": "nl",
            "protocol": "vless",
            "settings": {"vnext": [{"address": "example.net", "port": 2149, "users": [{"id": "11111111-2222-4333-8444-555555555555", "encryption": "none"}]}]},
            "streamSettings": {"network": "grpc", "security": "reality", "realitySettings": {"serverName": "github.io", "publicKey": "another_public_key", "fingerprint": "chrome"}, "grpcSettings": {"serviceName": "service-01"}},
        },
        {"tag": "direct", "protocol": "freedom"},
    ],
}


class ProfileTests(unittest.TestCase):
    def test_import_extracts_all_proxy_outbounds_and_preserves_source(self):
        profiles = parse_profiles(json.dumps(SAMPLE))
        self.assertEqual([p["name"] for p in profiles], ["pl", "nl"])
        self.assertEqual(profiles[0]["source"], SAMPLE)

    def test_vless_link_has_xhttp_reality_fields(self):
        link = vless_link(parse_profiles(json.dumps(SAMPLE))[0])
        self.assertIn("vless://11111111-2222-4333-8444-555555555555@example.org:443?", link)
        self.assertIn("type=xhttp", link)
        self.assertIn("security=reality", link)
        self.assertIn("pbk=test_public_key", link)
        self.assertIn("path=%2Fxhttp", link)

    def test_vless_link_has_grpc_service_name(self):
        link = vless_link(parse_profiles(json.dumps(SAMPLE))[1])
        self.assertIn("type=grpc", link)
        self.assertIn("serviceName=service-01", link)

    def test_rejects_non_proxy_config(self):
        with self.assertRaises(ValueError):
            parse_profiles('{"outbounds":[{"protocol":"freedom"}]}')

    def test_monthly_usage_period_keeps_creation_day_when_possible(self):
        created = datetime(2026, 1, 31, 10, tzinfo=timezone.utc)
        self.assertEqual(panel_app.monthly_period_start(created, datetime(2026, 2, 27, tzinfo=timezone.utc)), created)
        self.assertEqual(panel_app.monthly_period_start(created, datetime(2026, 2, 28, 10, tzinfo=timezone.utc)),
                         datetime(2026, 2, 28, 10, tzinfo=timezone.utc))
        self.assertEqual(panel_app.monthly_period_start(created, datetime(2026, 3, 30, tzinfo=timezone.utc)),
                         datetime(2026, 2, 28, 10, tzinfo=timezone.utc))
        self.assertEqual(panel_app.monthly_period_start(created, datetime(2026, 3, 31, 10, tzinfo=timezone.utc)),
                         datetime(2026, 3, 31, 10, tzinfo=timezone.utc))


class ApiTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        app = create_app(Path(self.tmp.name) / "panel.db", "admin", hash_password("correct horse battery staple"))
        self.client = TestClient(app)

    def tearDown(self):
        self.client.close()
        self.tmp.cleanup()

    def login(self):
        r = self.client.post("/api/v1/auth/login", json={"username": "admin", "password": "correct horse battery staple"})
        self.assertEqual(r.status_code, 200)
        return {"Authorization": "Bearer " + r.json()["token"]}

    def test_admin_auth_and_subscription_lifecycle(self):
        self.assertEqual(self.client.get("/api/v1/hosts").status_code, 401)
        self.assertEqual(self.client.post("/api/v1/auth/login", json={"username": "admin", "password": "wrong"}).status_code, 401)
        headers = self.login()
        imported = self.client.post("/api/v1/hosts/import", json={"text": json.dumps(SAMPLE)}, headers=headers)
        self.assertEqual(imported.status_code, 201)
        self.assertEqual(len(imported.json()["hosts"]), 2)
        created = self.client.post("/api/v1/subscribers", json={"name": "Alice"}, headers=headers)
        self.assertEqual(created.status_code, 201)
        subscriber = created.json()
        token = subscriber["token"]
        response = self.client.get("/sub/" + token)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.headers["Referrer-Policy"], "no-referrer")
        links = base64.b64decode(response.text).decode().splitlines()
        self.assertEqual(len(links), 2)
        self.assertIn("example.org", links[0])
        host_id = imported.json()["hosts"][0]["id"]
        self.assertEqual(self.client.patch(f"/api/v1/hosts/{host_id}", json={"enabled": False}, headers=headers).status_code, 200)
        self.assertEqual(len(base64.b64decode(self.client.get("/sub/" + token).text).decode().splitlines()), 1)
        self.assertEqual(self.client.patch(f"/api/v1/subscribers/{subscriber['id']}", json={"enabled": False}, headers=headers).status_code, 200)
        self.assertEqual(self.client.get("/sub/" + token).status_code, 404)

    def test_expired_subscriber_receives_only_renewal_host(self):
        headers = self.login()
        created = self.client.post("/api/v1/subscribers", json={"name": "Expired", "expires_at": "2000-01-01T00:00:00Z"}, headers=headers)
        self.assertEqual(created.status_code, 201)
        token = created.json()["token"]
        response = self.client.get("/sub/" + token)
        self.assertEqual(response.status_code, 200)
        links = base64.b64decode(response.text).decode().splitlines()
        self.assertEqual(len(links), 1)
        self.assertTrue(links[0].startswith("ss://"))
        self.assertEqual(unquote(links[0].split("#", 1)[1]), "продлите подписку")
        self.assertNotIn("example.org", links[0])

    def test_subscription_title_support_and_happ_page(self):
        headers = self.login()
        created = self.client.post("/api/v1/subscribers", json={
            "name": "Buyer 1", "title": "Общак Плюс", "support_url": "https://t.me/support_example",
            "expires_at": "2030-01-01T00:00:00Z",
        }, headers=headers)
        self.assertEqual(created.status_code, 201)
        subscriber = created.json()
        self.assertEqual(subscriber["subscription_url"], f"http://testserver/sub/{subscriber['token']}")
        raw = self.client.get("/sub/" + subscriber["token"])
        self.assertEqual(base64.b64decode(raw.headers["profile-title"]).decode(), "Общак Плюс")
        self.assertEqual(raw.headers["support-url"], "https://t.me/support_example")
        self.assertEqual(raw.headers["hide-settings"], "1")
        page = self.client.get("/sub/" + subscriber["token"], headers={"Accept": "text/html"})
        self.assertEqual(page.status_code, 200)
        self.assertIn("Добавить в Happ", page.text)
        self.assertIn(f"happ://add/http://testserver/sub/{subscriber['token']}/raw", page.text)
        self.assertIn("https://t.me/support_example", page.text)
        explicit_raw = self.client.get(f"/sub/{subscriber['token']}/raw")
        self.assertEqual(explicit_raw.status_code, 200)
        self.assertEqual(explicit_raw.headers["hide-settings"], "1")
        self.assertEqual(self.client.get(f"/sub/{subscriber['token']}/links").headers["hide-settings"], "1")

    def test_api_key_creates_subscriber_but_cannot_manage_hosts(self):
        admin = self.login()
        response = self.client.post("/api/v1/api-keys", json={"name": "Telegram bot"}, headers=admin)
        self.assertEqual(response.status_code, 201)
        key = response.json()["key"]
        bot = {"Authorization": "Bearer " + key}
        created = self.client.post("/api/v1/users", json={
            "name": "buyer-42", "title": "Общак 42", "expires_at": "2030-02-01T00:00:00Z",
            "traffic_limit_gb": 30,
        }, headers=bot)
        self.assertEqual(created.status_code, 201)
        self.assertEqual(created.json()["traffic_limit_gb"], 30)
        self.assertTrue(created.json()["subscription_url"].endswith("/sub/" + created.json()["token"]))
        self.assertEqual(self.client.get(f"/api/v1/users/{created.json()['id']}", headers=bot).json()["title"], "Общак 42")
        self.assertEqual(self.client.get("/api/v1/hosts", headers=bot).status_code, 401)
        self.assertEqual(self.client.get("/api/v1/api-keys", headers=bot).status_code, 401)
        self.assertNotIn("key", self.client.get("/api/v1/api-keys", headers=admin).json()["api_keys"][0])
        self.assertEqual(self.client.delete(f"/api/v1/api-keys/{response.json()['id']}", headers=admin).status_code, 204)
        self.assertEqual(self.client.get("/api/v1/subscribers", headers=bot).status_code, 401)

    def test_existing_database_is_migrated_without_losing_subscribers(self):
        with tempfile.TemporaryDirectory() as tmp:
            db_path = Path(tmp) / "old.db"
            with closing(sqlite3.connect(db_path)) as db:
                db.execute("""CREATE TABLE subscribers (
                    id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
                    token TEXT NOT NULL UNIQUE, expires_at TEXT,
                    enabled INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL)""")
                db.execute("INSERT INTO subscribers(name,token,created_at) VALUES (?,?,?)",
                           ("Old", "old-token", "2026-01-01T00:00:00+00:00"))
                db.commit()
            app = create_app(db_path, "admin", hash_password("correct horse battery staple"))
            with TestClient(app) as client:
                response = client.get("/sub/old-token")
                self.assertEqual(response.status_code, 200)
                self.assertEqual(base64.b64decode(response.headers["profile-title"]).decode(), "Общак")

    def test_reported_usage_blocks_refresh_and_resets_each_month(self):
        headers = self.login()
        created = self.client.post("/api/v1/subscribers", json={"name": "Metered", "traffic_limit_gb": 1}, headers=headers).json()
        subscriber_id = created["id"]
        token = created["token"]
        limit = 1024**3
        reported = self.client.put(f"/api/v1/subscribers/{subscriber_id}/usage", json={
            "used_bytes": limit, "period_start": created["usage_period_start"]}, headers=headers)
        self.assertEqual(reported.status_code, 200)
        self.assertEqual(reported.json()["used_bytes"], limit)
        blocked = self.client.get("/sub/" + token)
        self.assertIn(f"download={limit}; total={limit}", blocked.headers["subscription-userinfo"])
        self.assertEqual(len(base64.b64decode(blocked.text).decode().splitlines()), 1)
        self.assertTrue(base64.b64decode(blocked.text).decode().startswith("ss://"))
        page = self.client.get("/sub/" + token, headers={"Accept": "text/html"})
        self.assertIn("Лимит трафика исчерпан", page.text)
        with closing(sqlite3.connect(Path(self.tmp.name) / "panel.db")) as db:
            db.execute("UPDATE subscribers SET usage_period_start='2020-01-01T00:00:00+00:00' WHERE id=?", (subscriber_id,))
            db.commit()
        reset = self.client.get("/api/v1/subscribers", headers=headers).json()["subscribers"][0]
        self.assertEqual(reset["used_bytes"], 0)
        self.assertEqual(reset["traffic_limit_gb"], 1)
        self.assertIn("download=0; total=1073741824", self.client.get("/sub/" + token).headers["subscription-userinfo"])
        stale = self.client.put(f"/api/v1/subscribers/{subscriber_id}/usage", json={
            "used_bytes": limit, "period_start": "2020-01-01T00:00:00+00:00"}, headers=headers)
        self.assertEqual(stale.status_code, 409)
        self.assertEqual(self.client.get(f"/api/v1/users/{subscriber_id}", headers=headers).json()["used_bytes"], 0)

    def test_user_api_rejects_invalid_fields_before_writing(self):
        headers = self.login()
        self.assertEqual(self.client.post("/api/v1/users", json={"name": "   "}, headers=headers).status_code, 422)
        self.assertEqual(self.client.post("/api/v1/users", json={"name": "Buyer", "support_url": "https://[invalid"}, headers=headers).status_code, 422)
        created = self.client.post("/api/v1/users", json={"name": "Buyer"}, headers=headers).json()
        self.assertEqual(self.client.put(f"/api/v1/users/{created['id']}/usage", json={
            "used_bytes": 2**63, "period_start": created["usage_period_start"]}, headers=headers).status_code, 422)


if __name__ == "__main__":
    unittest.main()
