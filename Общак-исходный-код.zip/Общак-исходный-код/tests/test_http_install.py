import shutil
import socket
import subprocess
import tempfile
import unittest
from pathlib import Path


PROJECT = Path(__file__).resolve().parents[1]


class HttpInstallTests(unittest.TestCase):
    def test_install_prepares_http_on_selected_port(self):
        with tempfile.TemporaryDirectory() as tmp:
            workdir = Path(tmp) / "panel"
            shutil.copytree(PROJECT, workdir, ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "data", ".env", "Caddyfile"))
            with socket.socket() as probe:
                probe.bind(("127.0.0.1", 0))
                port = probe.getsockname()[1]

            answers = f"2\n127.0.0.1\n{port}\nadmin\nexample-password-123\n"
            result = subprocess.run(
                ["bash", "install.sh", "--prepare-only"], cwd=workdir,
                input=answers, text=True, capture_output=True, check=True,
            )

            self.assertIn(f"http://127.0.0.1:{port}", result.stdout)
            self.assertEqual((workdir / "Caddyfile").read_text().splitlines()[0], "http://127.0.0.1 {")
            self.assertIn("reverse_proxy app:8000", (workdir / "Caddyfile").read_text())
            self.assertNotIn("tls internal", (workdir / "Caddyfile").read_text())
            self.assertIn(f"PANEL_PORT={port}", (workdir / ".env").read_text())


if __name__ == "__main__":
    unittest.main()
